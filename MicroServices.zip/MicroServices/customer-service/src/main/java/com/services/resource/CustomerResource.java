package com.services.resource;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import freemarker.core.JSONOutputFormat;

@RestController
@RequestMapping("/customerservice")
public class CustomerResource {
    
	@Autowired
	private RestTemplate template;
	
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getCustomer/{userName}")
	public List<String> getCustomer(@PathVariable("userName")String userName){
		
		
		/*
		 * HttpHeaders headers = new HttpHeaders();
		 * headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON)); HttpEntity
		 * <String> entity = new HttpEntity<String>(headers);
		 */
		/*
		 * ResponseEntity<List<String>> response =
		 * template.exchange("http://db-service/db/customer/"+userName, HttpMethod.GET,
		 * entity, new ParameterizedTypeReference<List<String>>() { });
		 * 
		 * List<String> email = response.getBody();
		 * 
		 * System.out.println("email --->"+email);
		 * 
		 * return email;
		 */
				
							      
			    //  return template.exchange("http://db-service/db/customer/"+userName, HttpMethod.GET, entity, List.class).getBody();
				
		return template.getForObject("http://db-service/db/customer/"+userName, List.class);
	}
	
}
