package com.services.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.services.model.Customer;
import com.services.repository.CustomerRepository;

@RestController
@RequestMapping("/db/customer")
public class CustomerResource {
	
	@Autowired
	CustomerRepository repository;
	
	@PostMapping("/save")
	public void save(@RequestBody Customer customer) {
		repository.save(customer);
	}
	
	
	@GetMapping(value = "{userName}")
	public List<String> getCustomerByUserName(@PathVariable("userName") String userName){
		
		  return repository.findByUserName(userName).stream() .map(Customer::getEmail).
		  collect(Collectors.toList());
		 
		
	
		/*
		 * List<String> custEmail=new ArrayList<String>();
		 * 
		 * for(Customer customer:customerList) { custEmail.add(customer.getEmail()); }
		 */
		//return customerList;
	}

}
